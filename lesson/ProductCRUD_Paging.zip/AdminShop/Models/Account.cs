using System.ComponentModel.DataAnnotations;
namespace AdminShop.Models;
public class Account { public int Id{get;set;} [Required] public string Name{get;set;}=""; [Required,EmailAddress] public string Email{get;set;}=""; public string? Avatar{get;set;} [Required] public string Password{get;set;}=""; }
