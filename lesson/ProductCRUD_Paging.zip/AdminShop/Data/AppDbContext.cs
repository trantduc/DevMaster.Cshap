using AdminShop.Models;
using Microsoft.EntityFrameworkCore;
namespace AdminShop.Data;
public class AppDbContext:DbContext {
 public AppDbContext(DbContextOptions<AppDbContext> options):base(options){}
 public DbSet<Category> Categories=>Set<Category>(); public DbSet<Product> Products=>Set<Product>();
 public DbSet<Blog> Blogs=>Set<Blog>(); public DbSet<Banner> Banners=>Set<Banner>(); public DbSet<Account> Accounts=>Set<Account>();
 public DbSet<Customer> Customers=>Set<Customer>(); public DbSet<Order> Orders=>Set<Order>(); public DbSet<OrderDetail> OrderDetails=>Set<OrderDetail>();
 protected override void OnModelCreating(ModelBuilder b){
  b.Entity<OrderDetail>().HasKey(x=>new{x.OrderId,x.ProductId});
  b.Entity<Category>().HasData(
   new Category{Id=1,Name="Sách giáo khoa",Status=1,CreatedDate=new DateTime(2023,9,27,7,5,27),Description="Sách giáo khoa"},
   new Category{Id=2,Name="Văn học",Status=1,CreatedDate=new DateTime(2023,9,27,7,13,59),Description="Văn học"},
   new Category{Id=3,Name="Kinh tế/ Kinh doanh",Status=1,CreatedDate=new DateTime(2023,9,27,7,14,42),Description="Kinh tế/ Kinh doanh"},
   new Category{Id=4,Name="Kỹ năng/Sống đẹp",Status=1,CreatedDate=new DateTime(2023,9,27,7,15,14),Description="Kỹ năng/Sống đẹp"},
   new Category{Id=5,Name="Thiếu nhi",Status=1,CreatedDate=new DateTime(2023,9,27,7,15,28),Description="Thiếu nhi"});
  b.Entity<Product>().HasData(
   new Product{Id=1,Name="Toán lớp 9",Price=75000,SalePrice=69000,Status=1,CategoryId=1,Description="Sách Toán",CreatedDate=new DateTime(2024,1,1)},
   new Product{Id=2,Name="Ngữ văn chọn lọc",Price=95000,SalePrice=85000,Status=1,CategoryId=2,Description="Sách văn học",CreatedDate=new DateTime(2024,1,2)},
   new Product{Id=3,Name="Kinh doanh căn bản",Price=120000,SalePrice=99000,Status=1,CategoryId=3,Description="Sách kinh doanh",CreatedDate=new DateTime(2024,1,3)},
   new Product{Id=4,Name="Kỹ năng giao tiếp",Price=110000,SalePrice=89000,Status=1,CategoryId=4,Description="Kỹ năng",CreatedDate=new DateTime(2024,1,4)},
   new Product{Id=5,Name="Truyện thiếu nhi",Price=65000,SalePrice=59000,Status=1,CategoryId=5,Description="Thiếu nhi",CreatedDate=new DateTime(2024,1,5)},
   new Product{Id=6,Name="Vật lý lớp 9",Price=70000,SalePrice=65000,Status=1,CategoryId=1,Description="Sách Vật lý",CreatedDate=new DateTime(2024,1,6)});
 }
}
