using Microsoft.AspNetCore.Mvc;
namespace AdminShop.Controllers;
public class HomeController:Controller { public IActionResult Index()=>View(); }
