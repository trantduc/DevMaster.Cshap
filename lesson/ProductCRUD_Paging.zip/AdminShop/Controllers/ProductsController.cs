using AdminShop.Data; using AdminShop.Models; using AdminShop.ViewModels;
using Microsoft.AspNetCore.Mvc; using Microsoft.AspNetCore.Mvc.Rendering; using Microsoft.EntityFrameworkCore;
namespace AdminShop.Controllers;
public class ProductsController:Controller {
 private readonly AppDbContext _db; private readonly IWebHostEnvironment _env;
 public ProductsController(AppDbContext db,IWebHostEnvironment env){_db=db;_env=env;}
 public async Task<IActionResult> Index(string? keyword,int page=1){
  const int pageSize=5; if(page<1)page=1;
  var q=_db.Products.Include(x=>x.Category).AsQueryable();
  if(!string.IsNullOrWhiteSpace(keyword)) q=q.Where(x=>x.Name.Contains(keyword));
  var count=await q.CountAsync(); var pages=Math.Max(1,(int)Math.Ceiling(count/(double)pageSize)); if(page>pages)page=pages;
  var items=await q.OrderBy(x=>x.Id).Skip((page-1)*pageSize).Take(pageSize).ToListAsync();
  return View(new ProductIndexVM{Items=items,Keyword=keyword,Page=page,TotalPages=pages});
 }
 public async Task<IActionResult> Details(int id){var x=await _db.Products.Include(p=>p.Category).FirstOrDefaultAsync(p=>p.Id==id);return x==null?NotFound():View(x);}
 public IActionResult Create(){LoadCategories();return View();}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Create(Product model,IFormFile? imageFile){
  if(ModelState.IsValid){model.Image=await SaveImage(imageFile);model.CreatedDate=DateTime.Now;_db.Add(model);await _db.SaveChangesAsync();return RedirectToAction(nameof(Index));}
  LoadCategories(model.CategoryId);return View(model);
 }
 public async Task<IActionResult> Edit(int id){var x=await _db.Products.FindAsync(id);if(x==null)return NotFound();LoadCategories(x.CategoryId);return View(x);}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Edit(int id,Product model,IFormFile? imageFile){
  if(id!=model.Id)return NotFound(); var old=await _db.Products.AsNoTracking().FirstOrDefaultAsync(x=>x.Id==id);if(old==null)return NotFound();
  if(ModelState.IsValid){model.Image=imageFile!=null?await SaveImage(imageFile):old.Image;model.CreatedDate=old.CreatedDate;_db.Update(model);await _db.SaveChangesAsync();return RedirectToAction(nameof(Index));}
  LoadCategories(model.CategoryId);return View(model);
 }
 public async Task<IActionResult> Delete(int id){var x=await _db.Products.Include(p=>p.Category).FirstOrDefaultAsync(p=>p.Id==id);return x==null?NotFound():View(x);}
 [HttpPost,ActionName("Delete"),ValidateAntiForgeryToken] public async Task<IActionResult> DeleteConfirmed(int id){var x=await _db.Products.FindAsync(id);if(x!=null){_db.Products.Remove(x);await _db.SaveChangesAsync();}return RedirectToAction(nameof(Index));}
 private void LoadCategories(int? selected=null)=>ViewBag.CategoryId=new SelectList(_db.Categories.OrderBy(x=>x.Name),"Id","Name",selected);
 private async Task<string?> SaveImage(IFormFile? f){if(f==null||f.Length==0)return null;var ext=Path.GetExtension(f.FileName);var name=$"{Guid.NewGuid():N}{ext}";var folder=Path.Combine(_env.WebRootPath,"images","products");Directory.CreateDirectory(folder);using var s=System.IO.File.Create(Path.Combine(folder,name));await f.CopyToAsync(s);return "/images/products/"+name;}
}
