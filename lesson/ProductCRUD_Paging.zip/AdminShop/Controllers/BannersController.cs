using AdminShop.Data; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace AdminShop.Controllers;
public class BannersController:Controller {
 private readonly AppDbContext _db; public BannersController(AppDbContext db)=>_db=db;
 public async Task<IActionResult> Index()=>View(await _db.Banners.AsNoTracking().ToListAsync());
}
