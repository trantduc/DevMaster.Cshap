using AdminShop.Data; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace AdminShop.Controllers;
public class BlogsController:Controller {
 private readonly AppDbContext _db; public BlogsController(AppDbContext db)=>_db=db;
 public async Task<IActionResult> Index()=>View(await _db.Blogs.AsNoTracking().ToListAsync());
}
