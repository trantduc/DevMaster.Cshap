using AdminShop.Data; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace AdminShop.Controllers;
public class AccountsController:Controller {
 private readonly AppDbContext _db; public AccountsController(AppDbContext db)=>_db=db;
 public async Task<IActionResult> Index()=>View(await _db.Accounts.AsNoTracking().ToListAsync());
}
