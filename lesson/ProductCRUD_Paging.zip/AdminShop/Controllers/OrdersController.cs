using AdminShop.Data; using Microsoft.AspNetCore.Mvc; using Microsoft.EntityFrameworkCore;
namespace AdminShop.Controllers;
public class OrdersController:Controller {
 private readonly AppDbContext _db; public OrdersController(AppDbContext db)=>_db=db;
 public async Task<IActionResult> Index()=>View(await _db.Orders.Include(x=>x.Customer).AsNoTracking().ToListAsync());
}
